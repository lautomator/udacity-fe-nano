// This is a temporary file until a back end is implemented
// and is for DEVELOPMENT only.

// This file does not go into version control

var keys = {
    cid: 'G3OTQDH2K15MWXNSSXGK5I3YX2MFFY0KAGENITTW2L2O5AXA',
    cse: 'C4N4KUSQYIXURV24BM2P45DMVOCQRKY5QG4H0GVOQANLYRMS'
};